const BOARD_SIZE = 5;
let playerRow, playerCol, playerName, waterSupply, actionsRemaining, cluesFound, oasesRefilled;

document.addEventListener('DOMContentLoaded', function() {
    
    playerRow = Math.floor(BOARD_SIZE / 2);
    playerCol = Math.floor(BOARD_SIZE / 2);
    playerName = '';
    waterSupply = 0;
    actionsRemaining = 0;
    cluesFound = 0;
    oasesRefilled = 0;

   
    document.addEventListener('keydown', function(event) {
        // Check if the game is over
        if (!isGameOver()) {
            let newPlayerRow = playerRow;
            let newPlayerCol = playerCol;
    
            switch(event.key) {
                case 'ArrowUp':
                    newPlayerRow = playerRow - 1;
                    break;
                case 'ArrowDown':
                    newPlayerRow = playerRow + 1;
                    break;
                case 'ArrowLeft':
                    newPlayerCol = playerCol - 1;
                    break;
                case 'ArrowRight':
                    newPlayerCol = playerCol + 1;
                    break;
            }
    
            
            if (isValidMove(newPlayerRow, newPlayerCol)) {
                const currentCell = document.querySelector(`.cell[data-row="${playerRow}"][data-col="${playerCol}"]`);
                currentCell.classList.remove('player');
                currentCell.dataset.water = 'false';
    
                playerRow = newPlayerRow;
                playerCol = newPlayerCol;
    
                const newCell = document.querySelector(`.cell[data-row="${playerRow}"][data-col="${playerCol}"]`);
                newCell.classList.add('player');
                newCell.dataset.water = 'true';
            }
        }
    });
    
    function isGameOver() {
        return cluesFound === 2 || oasesRefilled === 3 || waterSupply === 0 || actionsRemaining === 0;
    }
    
    
});



function startGame() {
    
    playerName = document.getElementById('player-name').value;
    waterSupply = parseInt(document.getElementById('water-supply').value);
    actionsRemaining = 3;
    cluesFound = 0;
    oasesRefilled = 0;
    document.getElementById('home-screen').style.display = 'none';
    document.getElementById('game-container').style.display = 'flex';


    document.getElementById('player-name-display').innerText = `Name: ${playerName}`;
    document.getElementById('water-supply-display').innerText = waterSupply;
    document.getElementById('actions-remaining').innerText = actionsRemaining;

    initializeBoard();
}

function initializeBoard() {
    const boardElement = document.getElementById('board');
    boardElement.innerHTML = ''; 

    
    for (let row = 0; row < BOARD_SIZE; row++) {
        for (let col = 0; col < BOARD_SIZE; col++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.dataset.row = row;
            cell.dataset.col = col;
            boardElement.appendChild(cell);
        }
    }

   
    const playerCell = document.querySelector(`.cell[data-row="${playerRow}"][data-col="${playerCol}"]`);
    playerCell.classList.add('player');
    playerCell.dataset.water = 'true';

  
    addOases();
    addClues();
}

function addOases() {
    const numOases = 4;
    for (let i = 0; i < numOases; i++) {
        const oasisRow = Math.floor(Math.random() * BOARD_SIZE);
        const oasisCol = Math.floor(Math.random() * BOARD_SIZE);
        const oasisCell = document.querySelector(`.cell[data-row="${oasisRow}"][data-col="${oasisCol}"]`);
        oasisCell.classList.add('oasis');
    }
}

function addClues() {
    const clueLocations = generateClueLocations();
    clueLocations.forEach(clue => {
        const clueCell = document.querySelector(`.cell[data-row="${clue.row}"][data-col="${clue.col}"]`);
        
        const clueType = Math.random() < 0.5 ? 'item1.png' : 'item2.png'; 
        clueCell.classList.add('clue');
        clueCell.dataset.clueType = clueType;
    });
}

function generateClueLocations() {
    const clueLocations = [];
    for (let i = 0; i < 6; i++) {
        let row = Math.floor(Math.random() * BOARD_SIZE);
        let col = Math.floor(Math.random() * BOARD_SIZE);
        clueLocations.push({ row, col });
    }
    return clueLocations;
}

function performAction(action) {
    if (actionsRemaining > 0) {
        switch (action) {
            case 'Move':
                
                break;
            case 'Dig':
                dig();
                break;
            default:
                console.log("Invalid action!");
        }
        actionsRemaining--;
        document.getElementById('actions-remaining').innerText = actionsRemaining;
        waterSupply--;
        document.getElementById('water-supply-display').innerText = waterSupply;

        
        if (cluesFound === 2 || oasesRefilled === 3 || waterSupply === 0 || actionsRemaining === 0) {
            endGame('Game Over');
        }
    }
}

function endGame(message) {
    
    const gameOverMessage = document.createElement('div');
    gameOverMessage.classList.add('game-over-message');
    gameOverMessage.textContent = message;
    document.body.appendChild(gameOverMessage);
}

function dig() {
    const currentCell = document.querySelector(`.cell[data-row="${playerRow}"][data-col="${playerCol}"]`);

    if (currentCell.classList.contains('clue')) {
       
        const randomNumber = Math.floor(Math.random() * 2) + 1; 
        if (randomNumber === 1) {
            currentCell.innerHTML = '<img src="item 1.png" alt="Clue1">';
            console.log('Found clue 1 under the sand!');
        } else {
            currentCell.innerHTML = '<img src="item 2.png" alt="Clue2">';
            console.log('Found clue 2 under the sand!');
        }
        cluesFound++;
        if (cluesFound === 2) {
            console.log('You have found all clues!');
        }
    } else if (currentCell.classList.contains('oasis')) {
        if (currentCell.classList.contains('water')) {
            console.log('You found an oasis!');
            if (oasesRefilled < 3) {
                waterSupply += 2; 
                oasesRefilled++;
            }
        } else {
            currentCell.innerHTML = '<img src="Oasis.png" alt="Drought">';
            console.log('You found a mirage!');
        }
    } else {
        currentCell.innerHTML = '<img src="HOLE.png" alt="Hole">';
        console.log('Nothing found under the sand.');
    }

    const playerCell = document.querySelector(`.cell.player`);
    playerCell.classList.remove('player');
}




function isValidMove(row, col) {
    return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
}
